package z_exam;

public class Exam02_12 {
//a. 가능
	/*
	public static void main(String[] args){
	}
	*/ 
	
//b. 가능
	 /*public static void main(String args[]){
	  }*/
	 
//c. 가능
	/*public static void main(String[] arv){
	}*/
	
//d. 불가능
	/*public void static main(String[] args){
		
	}*/

//e. 가능
	/*static public void main(String[] args){
		
	}*/
}
